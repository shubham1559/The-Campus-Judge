# Problem of Divide #
read two numbers a and b print a/b.
errors upto 10^-6 will be accepted.

### Constraints###
```
n<=50
```

###Example### 

#### Sample input####
```
4 2
```

#### Sample output####
```
2
```

