# Problem of Sums #
Read integer n, and then read n integers. Print sum of these n numbers.

### Constraints###
```
n<=50
```

###Example### 

#### Sample input####
```
2
4 5
```

#### Sample output####
```
9
```

