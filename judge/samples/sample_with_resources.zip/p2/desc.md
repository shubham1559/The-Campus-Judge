# Problem of Sums #
Read integer n, and then read n integers. Print sum of these n numbers.

###Input###
This is input method

###Output###
write output method here

### Constraints###
```
n<=50
1<y<100
```

###Example### 

#### Sample input####
```
2
1 4
```

#### Sample output####
```
5
```

