% ![The Campus Judge](scripts/banner.png)    
   The assignment name
% Author One
  Author Two