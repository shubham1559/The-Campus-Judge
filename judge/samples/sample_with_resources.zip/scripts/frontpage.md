% ![The Campus Judge](scripts/banner.png)    
   Sample Assignment
% Shubham Vishwakarma