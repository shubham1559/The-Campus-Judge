# Upload Only#
This is an upload only problem this wont be judged

###Input###
This is input method

###Output###
* one
* two
* three

### Constraints###
```
n<=50
1<y<100
```

###Example### 

#### Sample input####
```
4 2
```

#### Sample output####
```
2
```

