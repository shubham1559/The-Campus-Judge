#How to generate pdfs
This is a sample assignment file.
Sources folder cantains some useful code snnippets to convert description files to pdf documents. A sample desc.md file is given in this folder.

 `bash` is a script file; running this will generate pdf files for all the problems and for the assignment from desc.md files. run  `cd path/to/sources/directory` and  `sh bash`. bash file uses pandoc and xelatex to generate pdf files. these two must be installed . On windows you can use 
 ```
 pandoc "p1/desc.md" --latex-engine=xelatex --template sources/template.latex -o "p1/desc.pdf"
``` 
this will generate pdf for that particular problem
use this to generate pdf for the whole assignment
```
pandoc sources/frontpage.md p1/desc.md p2/desc.md p3/desc.md --latex-engine=xelatex --template sources/template.latex -o assignment.pdf
```