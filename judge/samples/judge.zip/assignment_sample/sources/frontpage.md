% ![The Campus Judge](sources/banner.png)    
   The assignment name
% Author One
  Author Two